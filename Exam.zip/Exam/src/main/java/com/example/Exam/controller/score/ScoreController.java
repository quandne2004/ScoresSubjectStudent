package com.example.Exam.controller.score;

import com.example.Exam.entity.Score;
import com.example.Exam.entity.Student;
import com.example.Exam.entity.Subject;
import com.example.Exam.service.score.ScoreService;
import com.example.Exam.service.student.StudentService;
import com.example.Exam.service.subject.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/scores")
public class ScoreController {

    @Autowired
    private ScoreService scoreService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private SubjectService subjectService;

    @GetMapping
    public String listScores(Model model) {
        model.addAttribute("scores", scoreService.getAllScores());
        return "listScores";
    }

    @GetMapping("/add")
    public String showAddScoreForm(Model model) {
        model.addAttribute("score", new Score());
        model.addAttribute("students", studentService.getAllStudents());
        model.addAttribute("subjects", subjectService.getAllSubjects());
        return "addScore";
    }

    @PostMapping("/add")
    public String addScore(
            @RequestParam("studentId") Long studentId,
            @RequestParam("subjectId") Long subjectId,
            @RequestParam("score1") Double score1,
            @RequestParam("score2") Double score2) {

        Optional<Student> studentOpt = studentService.getStudentById(studentId);
        Optional<Subject> subjectOpt = subjectService.getSubjectById(subjectId);

        if (studentOpt.isPresent() && subjectOpt.isPresent()) {
            Score score = new Score();
            score.setStudent(studentOpt.get());
            score.setSubject(subjectOpt.get());
            score.setScore1(score1);
            score.setScore2(score2);

            scoreService.saveScore(score);
        }

        return "redirect:/scores";
    }

    @GetMapping("/edit/{id}")
    public String showEditScoreForm(@PathVariable("id") Long id, Model model) {
        Optional<Score> scoreOpt = scoreService.getScoreById(id);

        if (scoreOpt.isPresent()) {
            Score score = scoreOpt.get();
            model.addAttribute("score", score);
            model.addAttribute("students", studentService.getAllStudents());
            model.addAttribute("subjects", subjectService.getAllSubjects());
        } else {
            // Handle the case where the score is not found
            return "redirect:/scores";
        }

        return "editScore";
    }

    @PostMapping("/edit")
    public String editScore(
            @RequestParam("id") Long id,
            @RequestParam("studentId") Long studentId,
            @RequestParam("subjectId") Long subjectId,
            @RequestParam("score1") Double score1,
            @RequestParam("score2") Double score2) {

        Optional<Student> studentOpt = studentService.getStudentById(studentId);
        Optional<Subject> subjectOpt = subjectService.getSubjectById(subjectId);

        if (studentOpt.isPresent() && subjectOpt.isPresent()) {
            Optional<Score> scoreOpt = scoreService.getScoreById(id);

            if (scoreOpt.isPresent()) {
                Score score = scoreOpt.get();
                score.setStudent(studentOpt.get());
                score.setSubject(subjectOpt.get());
                score.setScore1(score1);
                score.setScore2(score2);

                scoreService.saveScore(score);
            }
        }

        return "redirect:/scores";
    }

    @GetMapping("/delete/{id}")
    public String deleteScore(@PathVariable("id") Long id) {
        scoreService.deleteScore(id);
        return "redirect:/scores";
    }
}
