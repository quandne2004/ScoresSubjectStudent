package com.example.Exam.service.student;

import com.example.Exam.entity.Student;

import java.util.List;
import java.util.Optional;

public interface StudentService {

    void deleteStudent(Long id);
    void saveStudent(Student student);
    Optional<Student> getStudentById(Long id);
    List<Student> getAllStudents();
}
